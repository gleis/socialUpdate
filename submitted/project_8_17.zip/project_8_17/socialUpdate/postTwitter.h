//
//  postTwitter.h
//  socialUpdate
//
//  Created by Michael Gleissner on 8/10/11.
//  Copyright 2011 Harper College. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface postTwitter : NSObject

-(void) postTwit: (UIImage*) timage: (NSString*) tPostText;

@end
