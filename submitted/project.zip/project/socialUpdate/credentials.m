//
//  credentials.m
//  socialUpdate
//
//  Created by Michael Gleissner on 8/13/11.
//  Copyright 2011 Harper College. All rights reserved.
//

#import "credentials.h"
#import "socialUpdateAppDelegate.h"


@implementation credentials
@synthesize credView;


- (id)init
{
    self = [super init];
    if (self) {
               
    }
    
    return self;
}

-(NSArray*) getCreds: (NSString*) service
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
    NSString *documentsDirectory = [paths objectAtIndex:0]; 
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"Creds.plist"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if (![fileManager fileExistsAtPath: path])
    {
        //There is no plist containing credentials
        //load the modal view to get credentials
        getCredentialsViewController *myView = [[getCredentialsViewController alloc] init];
        socialUpdateAppDelegate *appDelegate = (socialUpdateAppDelegate *)[[UIApplication sharedApplication] delegate];
        myView.serviceName = service;
        [[appDelegate viewController] presentModalViewController:myView animated:YES];
    }
    
    // get documents path
    NSArray *paths2 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentsPath = [paths2 objectAtIndex:0];
    // get the path to our Data/plist file
    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"Creds.plist"];
    
    NSMutableDictionary* plistDict = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    
    NSString *value;
    value = [plistDict objectForKey:@"Service"];
    NSString *uname = [plistDict objectForKey:@"Username"];
    NSString *pword = [plistDict objectForKey:@"Password"];
    

    NSArray *credArray = [[NSArray alloc] initWithObjects:uname, pword, nil];
        
    return credArray;
   
}



- (void)dealloc {
        [super dealloc];
}

@end
